# 📊 Survey Data Visualization Dashboard

This project is a Streamlit web app that visualizes survey data using interactive charts and also allows exporting insights to a PDF report.

## Features

- Age Group distribution (bar chart)
- Preferred Mode of Learning (pie chart)
- Correlation heatmap of numeric fields
- PDF Report generation

## Getting Started

### 🔧 Install dependencies

```bash
pip install -r requirements.txt
```

### ▶️ Run the Streamlit App

```bash
streamlit run app.py
```

### 📝 Generate PDF Report

```bash
python generate_report.py
```

## 📁 Files

- `app.py` – Interactive web dashboard
- `generate_report.py` – PDF report generation
- `sample_survey_data.csv` – Survey dataset
- `requirements.txt` – Python dependencies
- `README.md` – Project info

## License

MIT License
