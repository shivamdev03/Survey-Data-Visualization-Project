import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import streamlit as st

# Load the CSV
df = pd.read_csv("sample_survey_data.csv")

# Create AgeGroup if missing
if 'AgeGroup' not in df.columns:
    bins = [0, 18, 25, 35, 45, 60, 100]
    labels = ['<18', '18-25', '26-35', '36-45', '46-60', '60+']
    df['AgeGroup'] = pd.cut(df['Age'], bins=bins, labels=labels)

st.title("📊 Survey Data Visualization")

# Age Group Chart
st.subheader("Age Group Distribution")
fig1, ax1 = plt.subplots()
sns.countplot(x='AgeGroup', data=df, palette='pastel', ax=ax1)
st.pyplot(fig1)

# Preferred Mode Pie Chart
st.subheader("Preferred Mode of Learning")
fig2, ax2 = plt.subplots(figsize=(6, 6))
df['PreferredMode'].value_counts().plot.pie(
    autopct='%1.1f%%', startangle=90, ax=ax2,
    colors=sns.color_palette('pastel'),
    wedgeprops={'edgecolor': 'white'}
)
ax2.set_ylabel('')
st.pyplot(fig2)

# Correlation Heatmap
st.subheader("Correlation Heatmap")
fig3, ax3 = plt.subplots()
sns.heatmap(df.select_dtypes(include='number').corr(), annot=True, cmap='coolwarm', ax=ax3)
st.pyplot(fig3)
