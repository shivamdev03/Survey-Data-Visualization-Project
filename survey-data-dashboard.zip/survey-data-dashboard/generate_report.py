import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

df = pd.read_csv("sample_survey_data.csv")

# Create AgeGroup column
if 'AgeGroup' not in df.columns:
    bins = [0, 18, 25, 35, 45, 60, 100]
    labels = ['<18', '18-25', '26-35', '36-45', '46-60', '60+']
    df['AgeGroup'] = pd.cut(df['Age'], bins=bins, labels=labels)

with PdfPages('survey_report.pdf') as pdf:
    # Bar Chart
    plt.figure(figsize=(8, 5))
    sns.countplot(x='AgeGroup', data=df, palette='pastel')
    plt.title('Distribution of Age Groups')
    plt.tight_layout()
    pdf.savefig()
    plt.close()

    # Pie Chart
    plt.figure(figsize=(6, 6))
    df['PreferredMode'].value_counts().plot.pie(
        autopct='%1.1f%%', startangle=90,
        colors=sns.color_palette('pastel'),
        wedgeprops={'edgecolor': 'white'}
    )
    plt.title('Preferred Mode of Learning')
    plt.ylabel('')
    plt.tight_layout()
    pdf.savefig()
    plt.close()

    # Heatmap
    plt.figure(figsize=(8, 6))
    sns.heatmap(df.select_dtypes(include='number').corr(), annot=True, cmap='coolwarm')
    plt.title('Correlation Heatmap')
    plt.tight_layout()
    pdf.savefig()
    plt.close()
